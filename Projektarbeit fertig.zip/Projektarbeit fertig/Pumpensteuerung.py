import socket

UDP_IP = '127.0.0.1'
UDP_PORT_B14 = 1613

UDP_PORT_Q3 = 1702

# Socket erstellen und an IP und Port binden
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((UDP_IP, UDP_PORT_B14))



while True:
    try:
        # Nachricht vom Taster empfangen
        data, addr = sock.recvfrom(1024)  # 1024 ist die Puffergröße
        message = data.decode('utf-8').strip()
        print(f"Empfangen vom Taster: {message}")

        sock.sendto(bytes(message, "utf-8"), (UDP_IP, UDP_PORT_Q3))


   
    
    except KeyboardInterrupt:
        print("Programm beendet.")
        break

sock.close()