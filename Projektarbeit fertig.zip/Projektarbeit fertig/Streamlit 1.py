import streamlit as st
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
import time
import threading

# Configure your InfluxDB connection
url = "http://localhost:8086/"
token = "1gRmrm7A3Bi_cEhp29JTNOQ4KMoIMPCmY1Hk_Wo0fdT7MoBDb4joWfoH0JmUHChL-YluqzKUbRtt7AqifIPn4w=="
org = "sfb"
bucket = "test"  # Replace with the name of the bucket you want to write to
 
# Create a client instance
client = InfluxDBClient(url=url, token=token, org=org)
 
# Get the write API
write_api = client.write_api(write_options=SYNCHRONOUS)

# Abrufen des Query-APIs (zum Abfragen von Daten)
query_api = client.query_api()

# Flux-Abfrage für die letzten Einträge in der InfluxDB
istwert_query = f'''
from(bucket:"{bucket}")
  |> range(start: -1h)  // Zeitraum für die letzten 1 Stunde
  |> filter(fn: (r) => r["_measurement"] == "schalter")  // Filter nach der Messung "schalter"
  |> filter(fn: (r) => r["port"] == "1604")
  |> last() // Holen des letzten Eintrags
'''





Regen_query = f'''
from(bucket:"{bucket}")
  |> range(start: -1h)  // Zeitraum für die letzten 1 Stunde
  |> filter(fn: (r) => r["_measurement"] == "schalter")  // Filter nach der Messung "schalter"
  |> filter(fn: (r) => r["port"] == "1602")
  |> last() // Holen des letzten Eintrags

'''


Wind_query = f'''
from(bucket:"{bucket}")
  |> range(start: -1h)  // Zeitraum für die letzten 1 Stunde
  |> filter(fn: (r) => r["_measurement"] == "schalter")  // Filter nach der Messung "schalter"
  |> filter(fn: (r) => r["port"] == "1601")
  |> last() // Holen des letzten Eintrags
'''


#Schlaltermapping
port_to_switch = {
    "B1": 1600,"B2": 1601,"B3": 1602,"B4": 1603,"B5": 1604,"B6": 1605,"B7": 1606,"B8": 1607,
    "B9": 1608,"B10": 1609,"B11": 1610,"B12": 1611,"B13": 1612,"B14": 1613,"B15": 1614,"B16": 1615,
    "S1": 1621,"S2": 1622,"S3": 1616,"S4": 1617,"S5": 1618,"S6": 1619,"S7": 1620,"S8": 1623,
    "S9": 1624,"S10": 1625,"S11": 1626,"S12": 1627,"S13": 1628,"S14": 1629,"S15": 1630,"S16": 1631,
    "S17": 1632,"S18": 1633,"S19": 1634,"P1": 1713,"P2": 1708,"E1": 1716,"E2": 1711,"E3": 1709,
    "E4": 1710,"E5": 1712,"E6": 1714,"M1": 1717,"Q1": 1700,"Q2": 1701,"Q3": 1702,"Q4": 1703,
    "Q5": 1704,"Q6": 1705,"Q7": 1706,"Q8": 1707,
}

umwanlung_Zahl_in_Tempartur = {i: round(i / 10, 1) for i in range(100, 401)}


umwanlung_Tempartur_in_Zahl = {40: 1000, 39: 966, 38: 933, 37: 900, 36: 866, 35: 833, 34: 800, 33: 766,
                               32: 733, 31: 700, 30: 666, 29: 633, 28: 600, 27: 566, 26: 533, 25: 500,
                               24: 466, 23: 433, 22: 400, 21: 366, 20: 333, 19: 300, 18: 266, 17: 233,
                               16: 200, 15: 166, 14: 133, 13: 100, 12: 66, 11: 33, 10: 0}


umwanlung_Zahl_in_Pronzent = {i: i * 10 for i in range(1000)}
 
# Umschreibung True or False für Influx
def write_to_influxd(port,value):
    if value == True:
        point = (
            Point("schalter")  # Measurement
            .tag("port", port)  # Tag für den Port des Schalters
            .field("value", 1)  # Field für den Wert
        )
    else:
        point = (
            Point("schalter")  # Measurement
            .tag("port", port)  # Tag für den Port des Schalters
            .field("value", 0)  # Field für den Wert
        )
    write_api.write(bucket=bucket, record=point)


   
def write_to_influxd_Porzent(port, percentage):
    """
    Schreibt einen Wert zwischen 1 und 100 Prozent in InfluxDB.

    :param port: Der Port als Tag für den Schalter.
    :param percentage: Prozentwert (1-100) für den Schalter.
    """
    # Sicherstellen, dass der Prozentsatz im gültigen Bereich liegt
    if not (0 <= percentage <= 1000):
        raise ValueError("Der Prozentwert muss zwischen 1 und 100 liegen.")
    
    # Erstelle den Datenpunkt
    point = (
        Point("schalter")  # Measurement
        .tag("port", port)  # Tag für den Port des Schalters
        .field("value", percentage)  # Field für den Prozentwert
    )
    
    # Schreibe den Punkt in InfluxDB
    write_api.write(bucket=bucket, record=point)






# Custom CSS für die Sidebar
st.markdown("""
<style>
    .sidebar .sidebar-content {
        padding: 10px;
    }
    .sidebar .sidebar-content h2 {
        color: #4CAF50;
    }
    .sidebar .sidebar-content .radio {
        padding: 5px 0;
    }
</style>
    """, unsafe_allow_html=True)
 
# Sidebar für Raumauswahl
with st.sidebar:
    st.title("Raumsteuerung")
    st.subheader("Wählen Sie einen Standort aus:")
    section = st.radio('', ('Schlafzimmer', 'Eingang', 'Wohnzimmer', 'Garage', 'Aussen', 'Keller', 'Test'))
 
# Wohnzimmer Steuerung ----------------------------------------------------------------------------------------------------
if section == 'Wohnzimmer':
    st.header("Lichtschalter Wohnzimmer")
   
    if 'E3' not in st.session_state:
        st.session_state.E3 = False
 
    def click_E3():
        st.session_state.E3 = not st.session_state.E3
        write_to_influxd(port=port_to_switch["E3"],value=st.session_state.E3)
       
    st.button('Lampe Ein/Aus', on_click=click_E3)
 
    if st.session_state.E3:
        st.write('Lampe Ein')
        st.image('Lampe Ein.jpg')
    else:
    
        st.write('Lampe Aus')
        st.image('Lampe Aus.jpg')
    


    st.header("Raumtemperaturregler Wohnzimmer")
 
    if "Slider_Wohnzimmer" not in st.session_state:
   

        # Erstelle einen Slider
        Termostat_slider = st.slider(
        "Wähle Temperatur:",
        min_value=0,
        max_value=40,
        value=20
    )
    
    Istwert = query_api.query(query=istwert_query)
    for table in Istwert:
        for record in table.records:
            istwert_value = record.get_value()
            

    if Termostat_slider in umwanlung_Tempartur_in_Zahl: 
        percentage = umwanlung_Tempartur_in_Zahl[int(Termostat_slider)]
        write_to_influxd_Porzent(port_to_switch["M1"], percentage)
        st.write(f"Die aktuelle eingestellte Temperatur beträgt: {umwanlung_Zahl_in_Tempartur[int(istwert_value)]}  °C")

    else:
            st.write("Ungültiger Slider-Wert.")

    



       
# Schlafzimmer Steuerung ----------------------------------------------------------------------------------------------------      
if section == 'Schlafzimmer':
    st.header("Lichtschalter Schlafzimmer")
   

    # Erstelle einen Slider
    Schlafzimmer_Slider = st.slider(
        "Wieviel Pronzen wird gewünscht:",  # Beschriftung des Sliders
        min_value=0,          # Minimalwert
        max_value=100,        # Maximalwert
        value=0              # Startwert
    )


    try:
        write_to_influxd_Porzent(port_to_switch ["E1"], umwanlung_Zahl_in_Pronzent [Schlafzimmer_Slider])
    
    except ValueError as e:
        print(f"Fehler: {e}")


        
       
# Keller Steuerung -------------------------------------------------------------------------------------------------------------        
if section == 'Keller':
    st.header("Lichtschalter Keller")
   
    if 'E2' not in st.session_state:
        st.session_state.E2 = False
 
    def click_E2():
        st.session_state.E2 = not st.session_state.E2
        write_to_influxd(port=port_to_switch["E2"],value=st.session_state.E2)
 
    st.button('Lampe Ein/Aus', on_click=click_E2)
 
    if st.session_state.E2:
        st.write('Lampe Ein')
        st.image('Lampe Ein.jpg')
    else:
       
        st.write('Lampe Aus')
        st.image('Lampe Aus.jpg')
 
 
# Eingang Steuerung ------------------------------------------------------------------------------------------------------        
if section == 'Eingang':
    st.header("Lichtschalter Eingang")
   
    if 'E4' not in st.session_state:
        st.session_state.E4 = False
 
    def click_E4():
        st.session_state.E4 = not st.session_state.E4
        write_to_influxd(port=port_to_switch["E4"],value=st.session_state.E4)
 
    st.button('Lampe Ein/Aus', on_click=click_E4)
   
 
    if st.session_state.E4:
        st.write('Lampe Ein')
        st.image('Lampe Ein.jpg')
    else:
        st.write('Lampe Aus')
        st.image('Lampe Aus.jpg')
    

       
# Aussen/Garten -------------------------------------------------------------------------------------------------------------        


# Funktion zum automatischen Ausschalten der Lampe
def auto_turn_off_lamp():
    time.sleep(15)  # Warten für 5 Sekunden
    st.session_state.E5 = False
    write_to_influxd(port=port_to_switch["E5"], value=False)
    st.experimental_rerun()  # Aktualisiere die Benutzeroberfläche

# Aussenbereich
if section == 'Aussen':
    st.header("Gartenbeleuchtung")
   
    if 'E5' not in st.session_state:
        st.session_state.E5 = False

    def click_E5():
        st.session_state.E5 = not st.session_state.E5
       
        write_to_influxd(port=port_to_switch["E5"], value=st.session_state.E5)
        
        # Wenn die Lampe eingeschaltet wird, starte den Auto-Off-Thread
        if st.session_state.E5:
            threading.Thread(target=auto_turn_off_lamp, daemon=True).start()

    st.button('Lampe Ein/Aus', on_click=click_E5)

    if st.session_state.E5:
        st.write('Lampe Ein')
        st.image('Lampe Ein.jpg')
    else:
        st.write('Lampe Aus')
        st.image('Lampe Aus.jpg')

       

    st.header("Markise")

        # Die Session-Variablen Q7 und Q8 werden initialisiert
    if 'Q7' not in st.session_state:
        st.session_state.Q7 = False
    if 'Q8' not in st.session_state:
        st.session_state.Q8 = False

    # Funktion zum Umschalten der Markise
    def click_Q7():
        if st.session_state.Q7:
            # Wenn Q7 bereits True ist, setze es auf False und Q8 auf True (Markise auf)
            st.session_state.Q7 = False
            st.session_state.Q8 = True
        else:
            # Wenn Q7 False ist, setze es auf True und Q8 auf False (Markise zu)
            st.session_state.Q7 = True
            st.session_state.Q8 = False

        # Anzeige der aktuellen Status der Markise
        st.write(f"Port Q7: {st.session_state.Q7}")
        st.write(f"Port Q8: {st.session_state.Q8}")
        
        # Schreibe in die InfluxDB
        write_to_influxd(port=port_to_switch["Q7"], value=st.session_state.Q7)
        write_to_influxd(port=port_to_switch["Q8"], value=st.session_state.Q8)

    # Button für das Umschalten der Markise
    st.button('Markise Auf/Ab', on_click=click_Q7)

    # Status der Markise anzeigen
    if st.session_state.Q7:
        st.write('Markise Zu')
    elif st.session_state.Q8:
        st.write('Markise Auf')
    else:
        st.write('Markise Zu.')


 


    while True:
         # Abfrage für Windwert (Port 1601)
            Windwert = query_api.query(query=Wind_query)
            for table in Windwert:
                for record in table.records:
                    wind_value = record.get_value()
                    st.write(f"Windwert: {wind_value}")

            # Abfrage für Regenwert (Port 1602)
            Regenwert = query_api.query(query=Regen_query)
            for table in Regenwert:
                for record in table.records:
                    regen_value = record.get_value()
                    st.write(f"Regenwert: {regen_value}")

            # Überprüfen der Bedingung, ob die Markise geschlossen werden sollte
            if wind_value > 300 or regen_value > 300:
                write_to_influxd(port=port_to_switch["Q7"], value=1)
                write_to_influxd(port=port_to_switch["Q8"], value=0)
                st.write("Markise wird geschlossen, da Wind oder Regen zu stark sind.")
            else:
                st.write("Bedingung nicht erfüllt, Markise bleibt offen.")
            
            # Warten (z.B. 10 Sekunden) bevor die nächste Abfrage erfolgt
            time.sleep(10)




# Garage -------------------------------------------------------------------------------------------------------------        
if section == 'Garage':
    st.header("Garagenbeleuchtung")
   
    if 'E6' not in st.session_state:
        st.session_state.E6 = False
 
    def click_E6():
        st.session_state.E6 = not st.session_state.E6
        write_to_influxd(port=port_to_switch["E6"],value=st.session_state.E6)

 
    st.button('Lampe Ein/Aus', on_click=click_E6)
 
    if st.session_state.E6:
        st.write('Lampe Ein')
        st.image('Lampe Ein.jpg')    
    else: 
        st.write('Lampe Aus')
        st.image('Lampe Aus.jpg')

if section == 'Garage':
    st.header("Garagentor Auf")

    # Initialisierung von Q4 und Q5, falls nicht bereits gesetzt
    if 'Q4' not in st.session_state:
        st.session_state.Q4 = False
    if 'Q5' not in st.session_state:
        st.session_state.Q5 = False

    def click_Q4():
        if st.session_state.Q4:
            # Wenn Q4 bereits True ist, setze es auf False und setze Q5 auf True
            st.session_state.Q4 = False
            st.session_state.Q5 = True
        else:
            # Wenn Q4 False ist, setze es auf True und Q5 auf False
            st.session_state.Q4 = True
            st.session_state.Q5 = False
        
        # Debug-Ausgaben zur Überprüfung
        st.write(f"Port Q4: {st.session_state.Q4}")
        st.write(f"Port Q5: {st.session_state.Q5}")
        
        # Schreibe in die InfluxDB
        write_to_influxd(port=port_to_switch["Q4"], value=st.session_state.Q4)
        write_to_influxd(port=port_to_switch["Q5"], value=st.session_state.Q5)

    # Button zum Umschalten
    st.button('Garagentor Auf/Ab', on_click=click_Q4)

    # Anzeige der aktuellen Status
    if st.session_state.Q4:
        st.write('Garagentor Auf')
        st.image('Garagentor auf.jpg')
    elif st.session_state.Q5:
        st.write('Garagentor Zu')
        st.image('Garagentor zu.jpg')
    else:
        st.write('Garagentor geschlossen.')
