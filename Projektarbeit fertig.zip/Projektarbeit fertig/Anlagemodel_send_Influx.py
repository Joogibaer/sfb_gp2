import socket
from influxdb_client import InfluxDBClient, Point
from influxdb_client.client.write_api import SYNCHRONOUS
from datetime import datetime
import threading

 
# Configure your InfluxDB connection
url = "http://localhost:8086/"
token = "1gRmrm7A3Bi_cEhp29JTNOQ4KMoIMPCmY1Hk_Wo0fdT7MoBDb4joWfoH0JmUHChL-YluqzKUbRtt7AqifIPn4w=="
org = "sfb"
bucket = "test"  # Replace with the name of the bucket you want to write to
 
# Create a client instance
client = InfluxDBClient(url=url, token=token, org=org)
 
# Get the write API
write_api = client.write_api(write_options=SYNCHRONOUS)
 


# Umschreibung True or False für Influx
def write_to_influxd_on_off(port,value):
    if value == True:
        point = (
            Point("schalter")  # Measurement
            .tag("port", port)  # Tag für den Port des Schalters
            .field("value", 1)  # Field für den Wert
        )
    else:
        point = (
            Point("schalter")  # Measurement
            .tag("port", port)  # Tag für den Port des Schalters
            .field("value", 0)  # Field für den Wert
        )
    write_api.write(bucket=bucket, record=point)



def write_to_influxd_Porzent(port, percentage):
    """
    Schreibt einen Wert zwischen 1 und 100 Prozent in InfluxDB.

    :param port: Der Port als Tag für den Schalter.
    :param percentage: Prozentwert (1-100) für den Schalter.
    """
    # Sicherstellen, dass der Prozentsatz im gültigen Bereich liegt
    if not (1 <= percentage <= 1000):
        raise ValueError("Der Prozentwert muss zwischen 1 und 100 liegen.")
    
    # Erstelle den Datenpunkt
    point = (
        Point("schalter")  # Measurement
        .tag("port", port)  # Tag für den Port des Schalters
        .field("value", percentage)  # Field für den Prozentwert
    )
    
    # Schreibe den Punkt in InfluxDB
    write_api.write(bucket=bucket, record=point)




# Funktion, um Daten von einem spezifischen Port zu empfangen
def receive_data_Prozent(port):
    # Erstellen eines UDP-Sockets
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Binden des Sockets an die angegebene IP-Adresse und Port
    sock.bind(("127.0.0.1", port))
    print(f"Socket gestartet und hört auf Port {port}...")

    while True:
        try:
            # Empfangen der Daten (maximale Größe: 1024 Bytes)
            data, addr = sock.recvfrom(1024)
            # Konvertiere die empfangenen Daten und schreibe sie in InfluxDB
            percentage = int(data.decode('utf-8'))  # Konvertiere die Daten in einen Integer
            write_to_influxd_Porzent(port, percentage)  # Schreibe in InfluxDB
            print(f"Empfangen von Port {port}: {percentage} von {addr}")
        except Exception as e:
            print(f"Fehler beim Empfangen auf Port {port}: {e}")
            break
    sock.close()








# Erstellen und Starten der Threads für zwei SocketsthreadB1 = threading.Thread(target=receive_data_Prozent, args=(1600,))
threadB1 = threading.Thread(target=receive_data_Prozent, args=(1600,))
threadB2 = threading.Thread(target=receive_data_Prozent, args=(1601,))
threadB3 = threading.Thread(target=receive_data_Prozent, args=(1602,))
threadB4 = threading.Thread(target=receive_data_Prozent, args=(1603,))
threadB5 = threading.Thread(target=receive_data_Prozent, args=(1604,))
threadE6 = threading.Thread(target=receive_data_Prozent, args=(1714,))


# Starten der Threads
threadB1.start()
threadB2.start()
threadB3.start()
threadB4.start()
threadB5.start()
threadE6.start()


try:
        threadB1.join()
        threadB2.join()
        threadB3.join()
        threadB4.join()
        threadB5.join()
        threadE6.join()
   

except KeyboardInterrupt:
    print("Beende Empfang...")




