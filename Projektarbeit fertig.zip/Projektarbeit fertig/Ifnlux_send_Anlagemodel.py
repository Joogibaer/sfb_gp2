from influxdb_client import InfluxDBClient
import socket
import time

# Configure your InfluxDB connection
url = "http://localhost:8086/"
token = "1gRmrm7A3Bi_cEhp29JTNOQ4KMoIMPCmY1Hk_Wo0fdT7MoBDb4joWfoH0JmUHChL-YluqzKUbRtt7AqifIPn4w=="
org = "sfb"
bucket = "test"
UDP_IP = "127.0.0.1"
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Create a client instance
client = InfluxDBClient(url=url, token=token, org=org)

# Get the query API
query_api = client.query_api()

# Flux query to get the last weather records
query = f'''
from(bucket:"{bucket}")
  |> range(start: -1h)
  |> filter(fn: (r) => r["_measurement"] == "schalter")
  |> last()
'''

# Infinite loop to fetch and send data
try:
    while True:
        # Execute the query
        result = query_api.query(query=query)
        
        # Process and send results
        for table in result:
            for record in table.records:
                value = record.get_value()
                port = record.values.get('port', 'Unknown')

                if not isinstance(port, int):
                    try:
                        port = int(port)
                    except ValueError:
                        print(f"Ungültiger Portwert: {port}")
                        continue
                
                print(f"Value: {value}, Port: {port}")
                
                # Ensure valid port range
                if 0 <= port <= 65535:
                    try:
                        sock.sendto(str(value).encode('utf-8'), (UDP_IP, port))
                        print(f"Gesendet: {value} an Port {port}")
                    except Exception as e:
                        print(f"Fehler beim Senden: {e}")
                else:
                    print(f"Port {port} liegt außerhalb des gültigen Bereichs.")
        
        # Wait before the next query
        time.sleep(1)

except KeyboardInterrupt:
    print("Beende Programm...")

finally:
    client.close()
    print("Client geschlossen")
